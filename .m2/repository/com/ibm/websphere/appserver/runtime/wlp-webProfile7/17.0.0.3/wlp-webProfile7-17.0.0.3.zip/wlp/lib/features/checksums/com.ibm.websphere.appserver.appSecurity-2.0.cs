#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.appSecurity-2.0.mf=85bbd7d16eb93c75da44013c0b69e313
lib/com.ibm.ws.security.authentication.tai_1.0.18.jar=1779e1c42c6f8aeb41b49a78ddc247fe
