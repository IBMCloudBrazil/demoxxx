#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.rls.jdbc_1.0.18.jar=92b302ec9df789cd4498109c7fb3d399
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.18.jar=2ecce55a2f2f172fe415ce562da6bb7d
lib/com.ibm.ws.transaction_1.0.18.jar=febb09be482dfad1245257dbfa759482
lib/com.ibm.tx.jta_1.0.18.jar=a5ed18b9b3a6caaf73bbbc46bae564a2
lib/com.ibm.ws.tx.embeddable_1.0.18.jar=6fd1584c206698c05d5f6c8b1359e69d
lib/com.ibm.tx.ltc_1.0.18.jar=ba20462c7ce0986a0c47de90aa41691c
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=604fc5202b447386b00ee7f00ef8706e
lib/com.ibm.ws.transaction.cdi_1.0.18.jar=be5330cd6557b21eb0bb7da7c67ea352
lib/com.ibm.ws.cdi.1.2.interfaces_1.0.18.jar=e1a027a2c6bb2ba37d134d7e498cc5a9
lib/features/com.ibm.websphere.appserver.transaction-1.2.mf=8ee3c6c280e430842a50b04d0da97bc8
lib/com.ibm.tx.util_1.0.18.jar=7d66af17a7f3c52061ec92f8295a17dc
lib/com.ibm.ws.tx.jta.extensions_1.0.18.jar=0c54ef6dd1cb5e750a2df50b989a79e9
lib/com.ibm.ws.recoverylog_1.0.18.jar=bf682d0178d67caec591f5be1e634611
