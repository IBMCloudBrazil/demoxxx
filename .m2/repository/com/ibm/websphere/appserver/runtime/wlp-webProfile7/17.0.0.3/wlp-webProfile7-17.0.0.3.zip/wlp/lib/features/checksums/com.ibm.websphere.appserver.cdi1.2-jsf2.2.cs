#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.cdi.1.2.jsf_1.0.18.jar=8451b644972bd150ba174eea2eae9353
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=f62c27626d51b29c548b7e198b340dba
