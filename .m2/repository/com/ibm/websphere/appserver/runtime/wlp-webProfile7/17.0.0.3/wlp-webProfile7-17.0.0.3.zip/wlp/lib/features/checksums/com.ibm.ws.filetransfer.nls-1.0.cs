#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.filetransfer.nls_1.0.18.jar=a7847d64ee271e2ce8ce6098ecb8739e
lib/features/com.ibm.ws.filetransfer.nls-1.0.mf=5f2b407e8a5aeeaa57fffb638bfdaeff
