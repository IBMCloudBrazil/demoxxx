#Fri Oct 13 05:04:07 BST 2017
lib/com.ibm.ws.jca.cm_1.0.18.jar=dc866b1f145cc44d1f212167c675012d
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=35a43c3c4863c22f0808655a30a360c1
