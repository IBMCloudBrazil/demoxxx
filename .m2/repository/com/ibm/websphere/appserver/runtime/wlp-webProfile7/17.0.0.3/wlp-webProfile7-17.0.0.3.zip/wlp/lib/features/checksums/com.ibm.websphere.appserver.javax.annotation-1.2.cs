#Fri Oct 13 05:04:06 BST 2017
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.18.jar=1d8370f97082accc6b55d5b4ddaec555
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=075a7db6d3d49b6a80c08f1807d08264
