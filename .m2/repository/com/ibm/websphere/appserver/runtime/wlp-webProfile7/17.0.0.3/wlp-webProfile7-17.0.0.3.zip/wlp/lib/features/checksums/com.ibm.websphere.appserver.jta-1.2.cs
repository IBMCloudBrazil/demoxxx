#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=0ca525dc07eed77764b8e8122d8802d9
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.18.jar=488add001d4b42aaaa6103fd18709b72
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.18.jar=956cbd0380ef33e9f3ecd4a086777943
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=1aa77d4855381dcf7f44eed27dc37dba
