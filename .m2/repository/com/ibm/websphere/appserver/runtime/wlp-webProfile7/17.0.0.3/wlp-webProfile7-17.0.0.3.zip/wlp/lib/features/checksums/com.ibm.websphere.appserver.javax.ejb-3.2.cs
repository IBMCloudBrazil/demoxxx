#Fri Oct 13 05:04:06 BST 2017
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.18.jar=ed681d8bacbd52a832bf2f1d6dd6f930
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=c26ffbbd492429545ea97c92bb7b66e7
