#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=1145934810d398efab7992a8a6cc6e42
lib/com.ibm.ws.ejbcontainer.jpa_1.0.18.jar=7a5af1e23a40f41ea772815b40e452a3
