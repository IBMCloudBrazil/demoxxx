#Fri Oct 13 05:04:06 BST 2017
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.18.jar=94e95b77ed725786acefa35c28f7dcb2
lib/com.ibm.ws.jpa.container.eclipselink_1.0.18.jar=4ac00df7fc6bc9b205f7f9d3db4f4b25
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=e96ea39e5337d2004f71ddc1f2811172
