#Fri Oct 13 05:04:05 BST 2017
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=011af492076632e3e47a9606e63c58d9
lib/com.ibm.ws.ejbcontainer.session_1.0.18.jar=3403f593fd7a1a7a1a32f7cbbba44ad0
