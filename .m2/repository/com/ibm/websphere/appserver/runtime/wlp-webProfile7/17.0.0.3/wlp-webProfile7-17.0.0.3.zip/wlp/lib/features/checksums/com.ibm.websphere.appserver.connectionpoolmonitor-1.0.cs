#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=18d27f2ac519bd46bdf5657ec1aaeeee
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.18.jar=e0b0ee9286f454f6697a554bc5df99b1
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=a53b422b771ea0090a52d2db276d09d4
lib/com.ibm.ws.connectionpool.monitor_1.0.18.jar=93a33e29f811a60cbe0f1372a171afee
