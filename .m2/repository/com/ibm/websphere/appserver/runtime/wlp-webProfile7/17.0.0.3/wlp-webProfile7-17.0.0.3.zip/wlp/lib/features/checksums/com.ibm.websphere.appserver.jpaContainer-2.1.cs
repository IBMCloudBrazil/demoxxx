#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.jpaContainer-2.1.mf=1da62c5c271c2b1bcdff65db0f10308c
lib/com.ibm.ws.jpa.container.thirdparty_1.0.18.jar=21764c38fc5bb2d03974d62a34c9b330
lib/com.ibm.ws.jpa.container_1.0.18.jar=2f0c8262f85b361241a095c7c6d7e19a
lib/com.ibm.ws.jpa.container.v21_1.0.18.jar=167b884e74a92ddf322a5c789a9081a1
