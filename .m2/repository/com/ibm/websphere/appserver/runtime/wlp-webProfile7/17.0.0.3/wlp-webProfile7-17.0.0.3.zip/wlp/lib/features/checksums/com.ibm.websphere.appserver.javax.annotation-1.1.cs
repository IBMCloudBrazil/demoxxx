#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=aae6fce35aaa084db0bbd3257bd23a8c
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.18.jar=a03bc2b2aedb97e1e7e9fbd6c8d9f467
