#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.managedobject_1.0.18.jar=ca1fa50c8e0a64d0c3fb53f6eae376b7
lib/com.ibm.ws.org.jboss.jdeparser.1.0.0_1.0.18.jar=033d36ffdc018ec83551af04d0546495
lib/com.ibm.ws.org.jboss.logging.3.3.0_1.0.18.jar=092fa4760091ea3d16b5ff74775c0bbd
lib/com.ibm.ws.org.jboss.classfilewriter.1.1.2_1.0.18.jar=ecb7c1b6674fe17955cb40862ff83c75
dev/api/spec/com.ibm.websphere.javaee.jstl.1.2_1.0.18.jar=bd5bcb46eacb83f628fdc216ac4591f0
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.cdi_1.0.18.jar=5a56df17e711e1668a9ef0be7837b0cc
dev/api/spec/com.ibm.websphere.javaee.jsf.2.2_1.0.18.jar=b41e69e966ca9ed23ce65e3427b6f4ac
lib/features/com.ibm.websphere.appserver.cdi-1.2.mf=ed5e773d6611d388b7e21ce6ebc4b1f7
lib/com.ibm.ws.cdi.1.2.interfaces_1.0.18.jar=e1a027a2c6bb2ba37d134d7e498cc5a9
lib/com.ibm.ws.org.jboss.weld.2.4.3_1.0.18.jar=08e3a1fc55ab60ca8e6c771dfee4201b
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
lib/com.ibm.ws.cdi.1.2.weld.impl_1.0.18.jar=499d99356ddb8caf4ffe81437ef42ec6
