#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=4aec3ce756c53cfdcec9d3a62658705f
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.18.jar=3e8f2619ded88ae0a29ddaebac10ec9d
