#Fri Oct 13 05:04:06 BST 2017
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.18.jar=d16e086195a8f718414076643e363172
lib/com.ibm.ws.wsoc.1.1_1.0.18.jar=b021255cf3fdddb0c5dbe73ebcfcb394
lib/com.ibm.ws.wsoc_1.0.18.jar=4041486b9852b34da8fc6591799f6ac2
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=10424383a7c5ab23788975ebb968e91c
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.18.jar=a912940551193e23c7c3efe38c6b00ed
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=02117218656445ff5dec03239154527b
