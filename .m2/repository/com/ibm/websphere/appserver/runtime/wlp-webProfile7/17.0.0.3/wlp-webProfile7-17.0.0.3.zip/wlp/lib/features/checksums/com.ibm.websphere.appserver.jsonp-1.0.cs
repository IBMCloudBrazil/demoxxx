#Fri Oct 13 05:04:07 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.18.jar=a1dfa6c5f205082903d7ccf4e4c8f054
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=7a3837a71dc17a30460d2a36fc7909e6
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.18.jar=2f791d00f4ef5f0f5492079be1916e5c
