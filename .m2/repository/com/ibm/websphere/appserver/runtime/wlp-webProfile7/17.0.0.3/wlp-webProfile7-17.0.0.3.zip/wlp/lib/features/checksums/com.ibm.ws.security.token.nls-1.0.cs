#Fri Oct 13 05:04:05 BST 2017
lib/com.ibm.ws.security.token.nls_1.0.18.jar=8f55f587544ec2490b29ba243a3482d3
lib/features/com.ibm.ws.security.token.nls-1.0.mf=c84e94d53bd7e29df5af2f6fd2dd019f
