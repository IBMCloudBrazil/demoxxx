#Fri Oct 13 05:04:07 BST 2017
lib/com.ibm.ws.security.token.ltpa.nls_1.0.18.jar=90f8477f5ae369fd160a98e986bfa3a9
lib/features/com.ibm.ws.security.token.ltpa.nls-1.0.mf=3f40bce3e92d1dd873601dc30d584f46
