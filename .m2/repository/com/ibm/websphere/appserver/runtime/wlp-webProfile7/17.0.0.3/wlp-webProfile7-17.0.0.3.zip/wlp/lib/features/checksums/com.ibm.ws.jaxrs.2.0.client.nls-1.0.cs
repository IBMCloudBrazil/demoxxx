#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.jaxrs.2.0.client.nls_1.0.18.jar=265d4b71738748c2e250cb0bdf395a31
lib/features/com.ibm.ws.jaxrs.2.0.client.nls-1.0.mf=535859fec153dfa47e542d056ae9dc06
