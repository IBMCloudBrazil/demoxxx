#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.security.token.s4u2_1.0.18.jar=882a6384403cad3602b4ffd68e70ee78
lib/features/com.ibm.websphere.appserver.autoSecurityS4U2-1.0.mf=5ee1d74aea53499533f483f83ac75939
