#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.18.jar=3f2cbf7250d31501c10c33ef97158566
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=d7fa4e0ecf2a5a6984b13d44a326197e
