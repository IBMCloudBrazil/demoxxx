#Fri Oct 13 05:04:06 BST 2017
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.webCache_1.1-javadoc.zip=ba2b0b0a45d73ebbd580bc55959be02d
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.webCache_1.0-javadoc.zip=43dcfc6cff002395b4132630c2e755cd
dev/api/ibm/schema/cachespec.xsd=4c363b074382cb0c1762f596c91bdfa4
lib/com.ibm.ws.dynacache.web_1.0.18.jar=b5d06ccea209ea984ef65648f7cb66bf
dev/api/ibm/com.ibm.websphere.appserver.api.webCache_1.1.18.jar=494500f7ef2cfd7fec89c1a50e296616
dev/spi/ibm/com.ibm.websphere.appserver.spi.webCache_1.0.18.jar=bf692bbb638db35f2b0ec59404efe713
lib/features/com.ibm.websphere.appserver.webCache-1.0.mf=3d8cda460d5d6c75ef7fcdcdccb06dc1
