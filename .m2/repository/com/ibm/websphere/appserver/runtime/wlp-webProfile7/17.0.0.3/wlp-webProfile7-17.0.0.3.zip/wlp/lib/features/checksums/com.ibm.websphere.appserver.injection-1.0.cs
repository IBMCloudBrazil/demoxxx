#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=6c3b6ce2f872fc42455d6dfada3cb8d1
lib/com.ibm.ws.injection_1.0.18.jar=cebb16de91367e177af16f0ad6b3814e
