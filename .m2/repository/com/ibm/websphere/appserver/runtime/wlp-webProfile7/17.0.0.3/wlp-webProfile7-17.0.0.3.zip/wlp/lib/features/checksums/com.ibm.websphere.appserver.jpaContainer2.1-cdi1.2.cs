#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.jpaContainer2.1-cdi1.2.mf=2f61798d9e49187b1936dff43ccfc33a
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.18.jar=6da81356b03e2132f368e3605a4571bf
