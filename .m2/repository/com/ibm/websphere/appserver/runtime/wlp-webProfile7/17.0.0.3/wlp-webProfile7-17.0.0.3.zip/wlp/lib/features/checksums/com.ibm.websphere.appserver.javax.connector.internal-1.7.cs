#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=1b66703bf497ab16bf21d58ace9f14aa
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.18.jar=d2e6f994e2a851a46d382fd76d1ce1b6
