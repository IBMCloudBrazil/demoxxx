#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.session.monitor_1.0.18.jar=bd7a0ca28e6026fdc7fc5ffca67b5049
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.18.jar=8b061598f0a6a1a668228cc3cd6b6821
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=1cbfb6f6a308262c9bb63a4869b672f4
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=3e1d54f10690ca80437ec312e04f2836
