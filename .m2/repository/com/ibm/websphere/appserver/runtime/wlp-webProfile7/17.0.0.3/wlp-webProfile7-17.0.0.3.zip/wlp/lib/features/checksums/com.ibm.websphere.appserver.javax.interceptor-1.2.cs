#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=f855eabf072248d27d51b9939253e9bd
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.18.jar=834160da3edf4668730469b709301674
