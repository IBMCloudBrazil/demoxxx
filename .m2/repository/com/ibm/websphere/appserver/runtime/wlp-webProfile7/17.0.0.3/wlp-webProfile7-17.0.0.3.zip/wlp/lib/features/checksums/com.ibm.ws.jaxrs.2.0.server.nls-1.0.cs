#Fri Oct 13 05:04:05 BST 2017
lib/features/com.ibm.ws.jaxrs.2.0.server.nls-1.0.mf=5c51031d6e8d4fda1dcfa24484ec3929
lib/com.ibm.ws.jaxrs.2.0.server.nls_1.0.18.jar=32a1a596477a75a17e2a62f5c38020e7
