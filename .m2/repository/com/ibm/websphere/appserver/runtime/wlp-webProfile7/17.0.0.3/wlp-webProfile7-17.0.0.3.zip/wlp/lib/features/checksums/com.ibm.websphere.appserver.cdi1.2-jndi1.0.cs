#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.ws.cdi.1.2.jndi_1.0.18.jar=e36edae7aec3e60b247ae286cf1bc93a
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=9920c62adaa3774dfd87b23933452afd
