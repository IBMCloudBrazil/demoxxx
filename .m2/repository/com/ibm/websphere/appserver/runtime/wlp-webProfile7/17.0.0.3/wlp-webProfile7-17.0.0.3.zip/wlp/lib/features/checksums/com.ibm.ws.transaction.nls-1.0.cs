#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.ws.transaction.nls-1.0.mf=4f8371c1f846f5600e438f81b4e08e22
lib/com.ibm.ws.transaction.nls_1.0.18.jar=c3b6f47704f81db3ab43aab2348e2d8b
