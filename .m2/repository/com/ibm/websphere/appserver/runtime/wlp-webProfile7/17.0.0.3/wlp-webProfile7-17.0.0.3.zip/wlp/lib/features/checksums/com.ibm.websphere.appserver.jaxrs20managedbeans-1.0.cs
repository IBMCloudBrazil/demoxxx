#Fri Oct 13 05:04:07 BST 2017
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.18.jar=a58ce1de9a62662f7d65013f1d20515d
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=cb67ada4cd4bdcce76b3cd2b24c78290
