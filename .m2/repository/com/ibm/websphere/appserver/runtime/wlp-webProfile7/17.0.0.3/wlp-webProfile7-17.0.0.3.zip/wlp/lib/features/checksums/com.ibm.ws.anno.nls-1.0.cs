#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.ws.anno.nls-1.0.mf=5212922d4687373289d0606845ebcd9b
lib/com.ibm.ws.anno.nls_1.0.18.jar=a8b50cd6d5dd46997d0db510f2e27cdb
