#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.ws.jaxrs.2.x.config.nls-1.0.mf=1eab7e41fd708af93357b13125a6b177
lib/com.ibm.ws.jaxrs.2.x.config.nls_1.0.18.jar=bdbe7c3cc30c0303a2e3ab78747c0770
