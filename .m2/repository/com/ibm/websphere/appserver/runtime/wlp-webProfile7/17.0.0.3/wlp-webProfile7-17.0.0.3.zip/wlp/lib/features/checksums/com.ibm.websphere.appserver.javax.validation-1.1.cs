#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.javax.validation-1.1.mf=ae0d96e6b26e9a96fb3cbb3c1057c0e7
dev/api/spec/com.ibm.websphere.javaee.validation.1.1_1.0.18.jar=a6c98247ef897d9fe7d65a03fd89e303
