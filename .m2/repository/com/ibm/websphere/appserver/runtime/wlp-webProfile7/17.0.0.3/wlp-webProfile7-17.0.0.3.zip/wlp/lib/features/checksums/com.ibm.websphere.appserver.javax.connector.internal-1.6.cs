#Fri Oct 13 05:04:06 BST 2017
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.18.jar=44b5be1e411bf513acb2c90cd2dc00da
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=b5ea35c74d9b3214d5f267ccb1ffa60b
