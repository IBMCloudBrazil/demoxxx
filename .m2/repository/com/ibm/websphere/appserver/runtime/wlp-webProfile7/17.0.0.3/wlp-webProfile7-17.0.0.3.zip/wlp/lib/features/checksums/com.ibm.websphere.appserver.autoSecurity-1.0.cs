#Fri Oct 13 05:04:06 BST 2017
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=2f829e9a425c259ee963098b1f7d83d5
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.18.jar=170b98e0edecd2eb978c242f87dd0831
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=07c13af9c551cb15186baf2616a7cc78
