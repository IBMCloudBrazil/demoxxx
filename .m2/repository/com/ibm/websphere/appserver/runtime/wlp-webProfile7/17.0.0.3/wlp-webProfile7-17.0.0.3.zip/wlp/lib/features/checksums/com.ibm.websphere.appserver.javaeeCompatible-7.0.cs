#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.javaeeCompatible-7.0.mf=2b5e93e81f69c12fc9da081940297dbf
lib/com.ibm.ws.javaee.version_1.0.18.jar=09e74319196116b7b75e1e5925bda8f0
