#Fri Oct 13 05:04:07 BST 2017
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.2.18.jar=18b9f4e6b273d322cac1984dea644607
lib/com.ibm.ws.transport.http_1.0.18.jar=3e8b73714347b61fe1d505a950bea7c4
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.2-javadoc.zip=acc1c2a1201768947a92c2f974783cd9
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=5fa96f85282941e35112043b147a104f
