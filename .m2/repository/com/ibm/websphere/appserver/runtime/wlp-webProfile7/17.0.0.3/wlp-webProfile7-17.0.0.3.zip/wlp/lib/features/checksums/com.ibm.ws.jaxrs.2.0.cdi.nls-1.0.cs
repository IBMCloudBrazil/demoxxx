#Fri Oct 13 05:04:07 BST 2017
lib/com.ibm.ws.jaxrs.2.0.cdi.nls_1.0.18.jar=106880a8855e35e7267931c711542e90
lib/features/com.ibm.ws.jaxrs.2.0.cdi.nls-1.0.mf=23149b1b32c7c6c5b454603c2e8c750a
