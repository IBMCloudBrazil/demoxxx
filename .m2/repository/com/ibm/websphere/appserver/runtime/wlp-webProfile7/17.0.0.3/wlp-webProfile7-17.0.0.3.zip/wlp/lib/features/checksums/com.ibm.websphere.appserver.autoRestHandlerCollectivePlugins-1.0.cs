#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.autoRestHandlerCollectivePlugins-1.0.mf=5bff65a7b20e6f1fbd058d5617ca34b6
dev/spi/ibm/com.ibm.websphere.appserver.spi.collectivePlugins_2.0.18.jar=fc7ff471011d18961541bc844cfd39ff
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.collectivePlugins_2.0-javadoc.zip=5c22fdc7fa0a7d8fe5570bbfa213f626
lib/com.ibm.websphere.collective.plugins_1.0.18.jar=1f3ddfa2a12c05552df6f880274ea1e5
