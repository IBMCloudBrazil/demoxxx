#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=c1a4d0562d73bf290f9ab5199a15d8e2
lib/com.ibm.ws.dynamic.bundle_1.0.18.jar=a5008b324e2952a0abdd1054fdfe881c
