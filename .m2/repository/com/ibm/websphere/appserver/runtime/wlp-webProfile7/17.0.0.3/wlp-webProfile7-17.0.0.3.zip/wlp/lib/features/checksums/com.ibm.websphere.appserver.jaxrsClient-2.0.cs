#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=25221b1f7f5241415469aca052a11be6
lib/com.ibm.ws.jaxrs.2.0.client_1.0.18.jar=f5b5f5881a4ae207bb4ead93ad70f553
