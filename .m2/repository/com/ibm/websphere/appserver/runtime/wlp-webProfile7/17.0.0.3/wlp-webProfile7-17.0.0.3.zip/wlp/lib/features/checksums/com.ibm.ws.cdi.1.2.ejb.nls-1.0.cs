#Fri Oct 13 05:04:07 BST 2017
lib/features/com.ibm.ws.cdi.1.2.ejb.nls-1.0.mf=6ce74545144bd46a37cb1db75cb3b1df
lib/com.ibm.ws.cdi.1.2.ejb.nls_1.0.18.jar=47976077914f18beb4e6811c8a1614eb
