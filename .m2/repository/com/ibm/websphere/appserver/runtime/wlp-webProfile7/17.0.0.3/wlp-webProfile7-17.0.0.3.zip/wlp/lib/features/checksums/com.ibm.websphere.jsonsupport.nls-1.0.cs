#Fri Oct 13 05:04:06 BST 2017
lib/com.ibm.websphere.jsonsupport.nls_1.0.18.jar=49388052a08067482e2e8fdeafcb2a43
lib/features/com.ibm.websphere.jsonsupport.nls-1.0.mf=e7edae0b31cf01b61d363d9ce1644b88
