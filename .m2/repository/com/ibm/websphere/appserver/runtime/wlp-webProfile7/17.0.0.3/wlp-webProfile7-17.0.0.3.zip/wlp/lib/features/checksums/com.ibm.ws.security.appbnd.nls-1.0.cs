#Fri Oct 13 05:04:06 BST 2017
lib/features/com.ibm.ws.security.appbnd.nls-1.0.mf=bfeb4c7a792b38334a2bcdb408ce0722
lib/com.ibm.ws.security.appbnd.nls_1.0.18.jar=8e81c547c9e37291a810245dbe5395d3
