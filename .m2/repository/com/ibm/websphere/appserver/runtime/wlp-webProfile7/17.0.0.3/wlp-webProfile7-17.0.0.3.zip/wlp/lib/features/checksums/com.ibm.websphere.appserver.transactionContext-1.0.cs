#Fri Oct 13 05:04:07 BST 2017
lib/com.ibm.ws.transaction.context_1.0.18.jar=39627a838897f8d9c7b5073e9102281a
lib/features/com.ibm.websphere.appserver.transactionContext-1.0.mf=4948262eb63f70eef8358b8257dcd7d1
